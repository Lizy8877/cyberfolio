import fonctions
import time

def interaction():
    print("🖖  Bienvenue sur votre logiciel de gestions de produits.")
    time.sleep(0.5)
    while True:
        try:
            choice = int(input("\n💭  Que souhaitez-vous faire ?\n1. Créer un fichier 'produits.txt'.\n2. Ajouter des produits.\n3. Voir les produits.\n4. Supprimer un produit.\n5. Recherche un produit.\n6. Trier les produits\n7. Quitter.\nVotre choix : "))
            if choice == 1:
                fonctions.creer_fichier_produits()
                time.sleep(0.5)
            elif choice == 2:
                fonctions.ajouter_produit()
                time.sleep(0.5)
                print("\n")
            elif choice == 3:
                print("\n".strip())
                fonctions.lire_produits()
                print("\n".strip())
                time.sleep(0.5)
            elif choice == 4:
                fonctions.suppr_produits()
                print("\n".strip())
                time.sleep(0.5)
            elif choice == 5:
                fonctions.recherche()
                time.sleep(0.5)
            elif choice == 6:
                fonctions.trier()
                time.sleep(0.5)
            elif choice == 7:
                print("\n✅  Merci d'avoir utilisé le gestionnaire de produits !\n©️ Baptiste AUSSANT & Elisabeth RIVIERE - 2024\n")
                break
            else:
                print("\n--> ⚠️  Je ne comprends pas ce que vous souhaitez.\n")
        except ValueError:
            print("\n--> ⚠️  Veuillez renseigner un entier.\n")

interaction()