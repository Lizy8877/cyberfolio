function play(note) {
    let file="sounds/" + note + ".wav";
    let audio = new Audio(file);
    audio.play();
    console.log(note);
}

const pianoclefs = document.getElementById('all').children;

for (let i = 0; i < pianoclefs.length; i++) {
    pianoclefs[i].addEventListener("click", () => {
        play(pianoclefs[i].id);
    })
}